#!/bin/bash
#Script to scrape a website and format output for personal or other application use
#Reference: 
#Youtube video by "Root tech" was useful on how to scrape a website, format output and use functions fo handle errors. How to Scrape a Web Page Using Bash Script https://www.youtube.com/watch?v=DZ0WKRmUTm4
#I have also used week 1 - week 6 scripting languages course material to complete this assignment. Specifically, Password complexity check, Functions, Condational statement and loops, editing tools (AWK, SED, Grep)
#webpage to scrape
url="https://www.cyber.gov.au/acsc/view-all-content/alerts"
#function to format error message print
wget=$(which wget)
printError()
{
    echo -e "\033[31mERROR:\033[0m $1"
}
#scrape website 
function scrape_page() 
{
    $wget -O outputfile $url &>./null
    #call function to check for errors
    check_errors
}
#Function to check for page downloading error
function check_errors()
{   
    #use if statement to check calling function "exit" value is not equal to zero (i.e success) then print error
    if [ $? -ne 0 ]; then
        #Call printError function for formatted error message printing 
        printError "Downloading page \"$url\" failed!"
        exit -1
    fi
}
#function to remove html tags and any surplus information from wget downloaded web content 
#Special acknowledgment to "TheFrugalComputerGuy" youtube channel for helpful videos on Linux Command Line (awk, sed, grep, RegEx and tr) - https://www.youtube.com/playlist?list=PLy7Kah3WzqrHPrgkBgwzXyfDDCvthdUfl 
function clean_HTMLandSurplus_text()
{
    cat ./outputfile | grep "alert" | sed -n '{
        s/title="/title>/g;
        s/<[^>]*>//g; s/">//g;
        s/.*about\s//g;
        s/^[.{\].*//g;
        s/.*Show.*//g;
        s/.*error.*//g;
        s/.*[Vv]iew.*//g;
        s/.*Sign.*//g;
        s/.*xt.*//g;
        s/\/\/.*//g;
        s/’/`/g;
        /^$/d;
        p
        }' | tr '\n' ' ' | sed -n '{
                s/HIGH\s/HIGH\n/g; #insert line break following HIGH, CRITICAL, MEDIUM and LOW
                s/CRITICAL\s/CRITICAL\n/g;
                s/MEDIUM\s/MEDIUM\n/g;
                s/LOW\s/LOW\n/g;
                s/ - Alert status: /\~ /g; #Replace Alert status with a fiels separator
                s/ [0-9]. [A-Z].. [0-9]..../\~ & /g;#add a field separator before date
                s/\t\t\t\s//g; #remove preceeding tabs and spaces in a line
                p
                }' > alerts.txt
    sed -i '/^[0-9]. [A-Z].. [0-9].... [A-Z]...$/d' alerts.txt #delete dates lines without supporting details
    # Call funtion to display cleaned up file
    cleanfileV1
	#sed -i "s/$regex/\n/g" $outfile
}
function cleanfileV1()
{
     #use if statement to check calling function "exit" value is not equal to zero (i.e success) then print error
    if [ $? -eq 0 ]; then
        #cleaned file content display
        cat ./alerts.txt
    else
        #Call printError function for formated error message printing
        printError "Page cleanup failed! \"$url\"\nSee uncleaned page content above\n"
        exit -1
    fi
}
#create a function to manage awk commands for formated data display
displaystats()
{
awk 'BEGIN {
    FS="~"; #specify field separator
    print("\n")
    print("| \033[34mSecurity Alert\033[0m                                                                                                                | \033[34mDate\033[0m               | \033[34mAlert Status\033[0m       |"); # Table header formatting
    print("___________________________________________________________________________________________________________________________________________________________________________");
}
{ 
    #Format specified columns output and print
    printf("| \033[33m%-125s\033[0m | \033[35m%-18s\033[0m | \033[36m%-18s\033[0m |\n", $1, $2, $3);
}
END {
    print("___________________________________________________________________________________________________________________________________________________________________________");
    print("\n")
    #Print the number of records displayed
    print("\033[31mThe number of records displayed is:\033[0m ",NR); 
    print("\n")


}' alerts.txt #File passed to awk command for parsing
}




#create a function to manage awk commands for formated data display
###########################################################################################################################
#                        Run main functions                                                                               #
###########################################################################################################################

./passwordcomplexity.sh #Running the 'passwordcomplexity.sh' script - Modified week 2 password strength verification task 
if [ $? -eq 0 ]; then #PasswordCheck.sh return value is stored in $? variable. 0 indicates success, others indicates error
    #Display text on terminal when password.sh script exit code is 0
    echo
    #create a menu display
    echo -e "\e[42mApplication Menu Options\e[0m\n"
    echo -e "1. \033[34mScrape website\e[0m"
    echo -e "2. \033[32mClean scraped data\e[0m"
    echo -e "3. \033[35mDisplay formatted data\e[0m"
    echo -e "4. \033[31mExit\e[0m"
    for (( i=1; i>0; i++ )) #Create an infinate loop for loop
	do
        read -p "Select a value 1 - 4: " userchoice # Read user input selection
        if [ $userchoice = 4 ]  #Check user input does not equal to exit
	         then
	            echo "Goodbye!"
	            break #exit the the loop when user input is EXIT or Exit or exit
            else
                case $userchoice in #Evaluation of user selection expression 
                    "1" )
                        #call web scraping function
                        scrape_page 
                    ;;
                    "2" )
                        #call source page clean-up function
                        clean_HTMLandSurplus_text 
                    ;; 
                    "3" )
                        displaystats ;;
                    * ) # invalid user input/selection message
                    echo -e "$userchoice \e[33mis not a valid selection, enter an integer value 1 - 4\e[0m"
                    ;;
                esac # End case statement
        fi
    done #exit for loop
else #When passwordcomplexity.sh script exit code is not 0 then immediately exit menu.sh with an exit code 1
    exit -1
fi