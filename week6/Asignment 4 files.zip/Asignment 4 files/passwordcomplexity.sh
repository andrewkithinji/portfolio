#!/bin/bash
#password complexity validation
echo 'A strong password has a length is >= 8, upper case, lower case and special characters $,@,#,%' # display enter password text to user/terminal
read -sp "Please enter a secret password: " password # capture user keyboard input password
len="${#password}" # extract the user password string length form the password variable
if test $len -ge 8 ; then  # checks if password string length is greater or equal to 8 characters
    echo "$password" | grep -q [0-9] # check if numbers are included in the password without printing the included results to the terminal
        if test $? -eq 0 ; then # confirm number(s) are included i.e. not equal to zero
            echo "$password" | grep -q [A-Z] # Check if uppercase characters are included in the password without printing the included results to the terminal
                if test $? -eq 0 ; then # confirm uppercase characters are included i.e. not equal to zero
                    echo "$password" | grep -q [a-z] # Check if lowercase characters are included in the password without printing the included results to the terminal
                        if test $? -eq 0 ; then # confirm lower characters are included i.e. not equal to zero
                            echo "$password" | grep -q [$,@,#,%] # Check if special characters ($,@,#,%) are included in the password without printing the included results to the terminal
                                if test $? -eq 0 ; then #confirm special characters are included i.e. not equal to zero 
                                    echo -e "\033[36mStrong password access granted!\e[0m" # Printout a message on terminal “Strong password” when password length is >= 8, upper case and lower case characters are included, as well as special characters $,@,#,% 
                                    exit 0  #success return code 0
                                else 
                                    echo -e "\033[31mWeak password include special chars\e[0m" # Print a message on terminal if special characters are not included
                                    exit 1 #Error return code
                                fi 
                        else 
                            echo -e "\033[31mWeak password include lower case char\e[0m" # Print a message on terminal if lower case characters are not included
                            exit 1 #Error return code
                        fi 
                else 
                    echo -e "\033[31mWeak password include capital char\e[0m"  # Print a message on terminal if upper case characters are not included
                    exit 1 #Error return code
                fi 
        else 
            echo -e "\033[31mPlease include the numbers in password it is weak password\e[0m"  # Print a message on terminal if numbers are not included
            exit 1 #Error return code
        fi 
else 
    echo -e "\033[31mPassword length should be greater than or equal 8 hence weak password\e[0m" # Print a message on terminal if password string length is less than 8 characters
    exit 1 #Error return code
fi