1. To run the application/script ensure Cyberalerts.sh file and Passwordcomplexity.sh file are stored locally in your working directory.
2. execute cyberalerts.sh script and it will automatically call Passwordcomplexity.sh script to check for password complexity. 
3.Password with length is >= 8, upper case, lower case and special characters $,@,#,% 
4 . Follow the program prompts. 
  
